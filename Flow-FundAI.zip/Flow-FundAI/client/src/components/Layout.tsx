import { Sidebar } from "./Sidebar";
import { Menu } from "lucide-react";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useLocation, Link } from "wouter";
import clsx from "clsx";
import { LayoutDashboard, Wallet, CreditCard } from "lucide-react";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/budgets", label: "Budgets", icon: Wallet },
  { href: "/transactions", label: "Transactions", icon: CreditCard },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar />
      
      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 z-50">
        <h1 className="font-bold font-display text-lg text-slate-900">FlowFundAI</h1>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger>
            <Menu className="w-6 h-6 text-slate-600" />
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0 bg-slate-900 text-white border-r-slate-800">
             <div className="p-6 border-b border-slate-800">
               <h1 className="text-xl font-bold font-display">FlowFundAI</h1>
             </div>
             <nav className="p-4 space-y-2">
                {navItems.map((item) => {
                  const isActive = location === item.href;
                  const Icon = item.icon;
                  return (
                    <Link key={item.href} href={item.href} onClick={() => setOpen(false)}>
                      <div className={clsx(
                        "flex items-center gap-3 px-4 py-3 rounded-xl transition-colors cursor-pointer",
                        isActive ? "bg-blue-600 text-white" : "text-slate-400"
                      )}>
                        <Icon className="w-5 h-5" />
                        <span className="font-medium">{item.label}</span>
                      </div>
                    </Link>
                  );
                })}
             </nav>
          </SheetContent>
        </Sheet>
      </div>

      <main className="flex-1 p-4 md:p-8 pt-20 md:pt-8 overflow-y-auto h-screen">
        <div className="max-w-7xl mx-auto space-y-8 pb-10">
          {children}
        </div>
      </main>
    </div>
  );
}
