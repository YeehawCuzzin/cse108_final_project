import { Layout } from "@/components/Layout";
import { StatsCard } from "@/components/StatsCard";
import { DollarSign, PieChart, TrendingUp, Activity, Sparkles } from "lucide-react";
import { useBudgets } from "@/hooks/use-budgets";
import { useTransactions } from "@/hooks/use-transactions";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RePieChart,
  Pie,
  Cell,
} from "recharts";
import { format } from "date-fns";
import { useState } from "react";

const COLORS = ["#1e3a8a", "#475569", "#2d5a8c", "#5a6b7d", "#3b4a6b", "#687a94"];

export default function Dashboard() {
  const { data: budgets, isLoading: loadingBudgets } = useBudgets();
  const { data: transactions, isLoading: loadingTransactions } = useTransactions();
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [analysis, setAnalysis] = useState("");

  const handleAIAnalysis = async () => {
    setAnalysisLoading(true);
    setAnalysis("");
    try {
      const response = await fetch("/api/analyze-spending", { method: "POST" });
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const text = decoder.decode(value);
          const lines = text.split("\n");
          for (const line of lines) {
            if (line.startsWith("data: ")) {
              const data = JSON.parse(line.slice(6));
              if (data.content) setAnalysis((prev) => prev + data.content);
              if (data.done) setAnalysisLoading(false);
            }
          }
        }
      }
    } catch (error) {
      console.error("Error:", error);
      setAnalysisLoading(false);
    }
  };

  if (loadingBudgets || loadingTransactions) {
    return (
      <Layout>
        <div className="animate-pulse space-y-8">
          <div className="h-8 w-48 bg-slate-200 rounded"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-slate-200 rounded-2xl"></div>
            ))}
          </div>
          <div className="h-96 bg-slate-200 rounded-2xl"></div>
        </div>
      </Layout>
    );
  }

  // Calculate stats
  const totalBudget = budgets?.reduce((sum, b) => sum + Number(b.limitAmount), 0) || 0;
  const totalSpent = budgets?.reduce((sum, b) => sum + Number(b.spent), 0) || 0;
  const remaining = totalBudget - totalSpent;
  const spendingPercentage = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;

  // Prepare chart data
  const categoryData = budgets?.map((b) => ({
    name: b.category.name,
    budget: Number(b.limitAmount),
    spent: Number(b.spent),
  }));

  const pieData = budgets
    ?.filter((b) => Number(b.spent) > 0)
    .map((b) => ({
      name: b.category.name,
      value: Number(b.spent),
    }));

  const recentTransactions = transactions?.slice(0, 5) || [];

  return (
    <Layout>
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-slate-500">Overview of your financial health</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatsCard
          title="Total Budget"
          value={`$${totalBudget.toLocaleString()}`}
          icon={DollarSign}
          colorClass="text-blue-600"
        />
        <StatsCard
          title="Total Spent"
          value={`$${totalSpent.toLocaleString()}`}
          trend={`${spendingPercentage.toFixed(1)}%`}
          trendUp={false}
          icon={Activity}
          colorClass="text-indigo-600"
        />
        <StatsCard
          title="Remaining"
          value={`$${remaining.toLocaleString()}`}
          trend={remaining > 0 ? "On Track" : "Over Budget"}
          trendUp={remaining > 0}
          icon={TrendingUp}
          colorClass="text-emerald-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Bar Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-900 mb-6">Budget vs Actual</h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 12 }} 
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 12 }} 
                  tickFormatter={(value) => `$${value}`}
                />
                <Tooltip 
                  cursor={{ fill: '#f1f5f9' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="budget" name="Budget Limit" fill="#94a3b8" radius={[4, 4, 0, 0]} />
                <Bar dataKey="spent" name="Actually Spent" fill="#1e3a8a" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col">
          <h3 className="text-lg font-bold text-slate-900 mb-6">Spending Distribution</h3>
          <div className="flex-1 min-h-[320px]">
             <ResponsiveContainer width="100%" height="100%">
              <RePieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={120}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData?.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </RePieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-4 justify-center mt-4">
             {pieData?.map((entry, index) => (
               <div key={index} className="flex items-center gap-2 text-sm text-slate-600">
                 <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                 {entry.name}
               </div>
             ))}
          </div>
        </div>
      </div>

      {/* AI Analysis Section */}
      {analysis && (
        <div className="bg-gradient-to-br from-blue-50 to-slate-50 p-6 rounded-2xl shadow-sm border border-blue-200">
          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-blue-900 mt-1 flex-shrink-0" />
            <div className="flex-1">
              <h3 className="text-lg font-bold text-blue-900 mb-2">AI Spending Insights</h3>
              <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">{analysis}</p>
            </div>
          </div>
        </div>
      )}

      {/* Recent Transactions */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <h3 className="text-lg font-bold text-slate-900">Recent Transactions</h3>
          <div className="flex gap-3">
            <Button
              onClick={handleAIAnalysis}
              disabled={analysisLoading}
              className="bg-blue-900 hover:bg-blue-800 text-white"
              data-testid="button-ai-analysis"
            >
              {analysisLoading ? "Analyzing..." : "Get AI Insights"}
            </Button>
            <a href="/transactions" className="text-sm font-medium text-blue-900 hover:text-blue-800 self-center">View All</a>
          </div>
        </div>
        <div className="divide-y divide-slate-100">
          {recentTransactions.map((tx) => (
            <div key={tx.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500">
                  <DollarSign className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-medium text-slate-900">{tx.description}</p>
                  <p className="text-xs text-slate-500">{format(new Date(tx.date), "MMM d, yyyy")}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-slate-900">-${Number(tx.amount).toFixed(2)}</p>
                <p className="text-xs text-slate-500">{tx.category.name}</p>
              </div>
            </div>
          ))}
          {recentTransactions.length === 0 && (
            <div className="p-8 text-center text-slate-500">No transactions found.</div>
          )}
        </div>
      </div>
    </Layout>
  );
}
