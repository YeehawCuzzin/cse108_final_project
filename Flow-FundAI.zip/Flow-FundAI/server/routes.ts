import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Categories
  app.get(api.categories.list.path, async (_req, res) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });

  app.post(api.categories.create.path, async (req, res) => {
    try {
      const input = api.categories.create.input.parse(req.body);
      const category = await storage.createCategory(input);
      res.status(201).json(category);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  // Budgets
  app.get(api.budgets.list.path, async (_req, res) => {
    const budgets = await storage.getBudgets();
    res.json(budgets);
  });

  app.post(api.budgets.create.path, async (req, res) => {
    try {
      const input = api.budgets.create.input.parse(req.body);
      const budget = await storage.createBudget(input);
      res.status(201).json(budget);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.budgets.update.path, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const input = api.budgets.update.input.parse(req.body);
      const budget = await storage.updateBudget(id, input);
      if (!budget) return res.status(404).json({ message: "Budget not found" });
      res.json(budget);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  // Transactions
  app.get(api.transactions.list.path, async (_req, res) => {
    const transactions = await storage.getTransactions();
    res.json(transactions);
  });

  app.post(api.transactions.create.path, async (req, res) => {
    try {
      const input = api.transactions.create.input.parse(req.body);
      const transaction = await storage.createTransaction(input);
      res.status(201).json(transaction);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.delete(api.transactions.delete.path, async (req, res) => {
    const id = Number(req.params.id);
    await storage.deleteTransaction(id);
    res.status(204).send();
  });

  // AI Analysis Endpoint
  app.post("/api/analyze-spending", async (req, res) => {
    try {
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      const budgets = await storage.getBudgets();
      const transactions = await storage.getTransactions();

      const budgetSummary = budgets
        .map(b => `${b.category.name}: $${b.spent}/$${b.limitAmount} spent`)
        .join(", ");

      const prompt = `Analyze this budget data and provide specific recommendations on where to cut spending:\n${budgetSummary}.\n\nProvide 3-4 actionable insights in a friendly, conversational tone.`;

      const stream = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [{ role: "user", content: prompt }],
        stream: true,
        max_completion_tokens: 1024,
      });

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || "";
        if (content) {
          res.write(`data: ${JSON.stringify({ content })}\n\n`);
        }
      }

      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } catch (error) {
      console.error("Error analyzing spending:", error);
      if (res.headersSent) {
        res.write(`data: ${JSON.stringify({ error: "Failed to analyze spending" })}\n\n`);
        res.end();
      } else {
        res.status(500).json({ error: "Failed to analyze spending" });
      }
    }
  });

  // Seed Data
  await storage.seedInitialData();

  return httpServer;
}
