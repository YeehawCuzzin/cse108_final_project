import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { BarChart3, TrendingDown, Zap } from "lucide-react";

export default function Home() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex flex-col justify-center items-center px-4">
      <div className="max-w-2xl text-center space-y-12">
        {/* Logo/Header */}
        <div className="space-y-4">
          <div className="flex justify-center mb-6">
            <div className="bg-blue-900 p-4 rounded-full">
              <BarChart3 className="w-12 h-12 text-white" />
            </div>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900">
            Welcome to <span className="text-blue-900">FlowFundAI</span>
          </h1>
          <p className="text-lg text-slate-600 leading-relaxed">
            Take control of your finances with intelligent budget tracking, real-time insights, and AI-powered spending recommendations. Understand where your money goes and optimize your spending habits.
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 space-y-3">
            <Zap className="w-8 h-8 text-blue-900 mx-auto" />
            <h3 className="font-semibold text-slate-900">Smart Tracking</h3>
            <p className="text-sm text-slate-600">Monitor your spending across categories with beautiful visualizations</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 space-y-3">
            <TrendingDown className="w-8 h-8 text-blue-900 mx-auto" />
            <h3 className="font-semibold text-slate-900">Budget Goals</h3>
            <p className="text-sm text-slate-600">Set spending limits and get alerts when you're approaching your budget</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 space-y-3">
            <BarChart3 className="w-8 h-8 text-blue-900 mx-auto" />
            <h3 className="font-semibold text-slate-900">AI Insights</h3>
            <p className="text-sm text-slate-600">Get personalized recommendations on where to cut expenses</p>
          </div>
        </div>

        {/* CTA Button */}
        <Button
          onClick={() => navigate("/budgets")}
          className="bg-blue-900 hover:bg-blue-800 text-white px-8 py-3 text-lg font-semibold rounded-lg shadow-md transition-all hover:shadow-lg"
          data-testid="button-explore-dashboard"
        >
          Explore Dashboard
        </Button>
      </div>
    </div>
  );
}
