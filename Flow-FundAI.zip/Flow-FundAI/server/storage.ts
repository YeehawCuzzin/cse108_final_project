import { db } from "./db";
import {
  categories, budgets, transactions,
  type Category, type InsertCategory,
  type Budget, type InsertBudget,
  type Transaction, type InsertTransaction,
  type BudgetWithCategory
} from "@shared/schema";
import { eq, sql } from "drizzle-orm";

export interface IStorage {
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  getBudgets(): Promise<BudgetWithCategory[]>;
  createBudget(budget: InsertBudget): Promise<Budget>;
  updateBudget(id: number, budget: Partial<InsertBudget>): Promise<Budget | undefined>;
  
  getTransactions(): Promise<(Transaction & { category: Category })[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  deleteTransaction(id: number): Promise<void>;
  
  // Helper to seed initial data
  seedInitialData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  async getBudgets(): Promise<BudgetWithCategory[]> {
    // Get budgets joined with categories
    const results = await db
      .select({
        budget: budgets,
        category: categories,
      })
      .from(budgets)
      .innerJoin(categories, eq(budgets.categoryId, categories.id));

    // Calculate spent amount for each budget
    const budgetsWithSpent = await Promise.all(results.map(async ({ budget, category }) => {
      const spentResult = await db
        .select({
          total: sql<string>`sum(${transactions.amount})`
        })
        .from(transactions)
        .where(eq(transactions.categoryId, category.id));
      
      const spent = Number(spentResult[0]?.total || 0);
      return { ...budget, category, spent };
    }));

    return budgetsWithSpent;
  }

  async createBudget(budget: InsertBudget): Promise<Budget> {
    const [newBudget] = await db.insert(budgets).values(budget).returning();
    return newBudget;
  }

  async updateBudget(id: number, updates: Partial<InsertBudget>): Promise<Budget | undefined> {
    const [updated] = await db
      .update(budgets)
      .set(updates)
      .where(eq(budgets.id, id))
      .returning();
    return updated;
  }

  async getTransactions(): Promise<(Transaction & { category: Category })[]> {
    const results = await db
      .select({
        transaction: transactions,
        category: categories,
      })
      .from(transactions)
      .innerJoin(categories, eq(transactions.categoryId, categories.id))
      .orderBy(sql`${transactions.date} DESC`);

    return results.map(r => ({ ...r.transaction, category: r.category }));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [newTransaction] = await db.insert(transactions).values(transaction).returning();
    return newTransaction;
  }

  async deleteTransaction(id: number): Promise<void> {
    await db.delete(transactions).where(eq(transactions.id, id));
  }

  async seedInitialData() {
    const existingCats = await this.getCategories();
    if (existingCats.length === 0) {
      // Seed Categories
      const cats = await db.insert(categories).values([
        { name: "Housing", color: "#3b82f6" }, // Blue-500
        { name: "Food", color: "#64748b" },    // Slate-500
        { name: "Transportation", color: "#0ea5e9" }, // Sky-500
        { name: "Entertainment", color: "#94a3b8" }, // Slate-400
        { name: "Utilities", color: "#2563eb" }, // Blue-600
      ]).returning();

      // Seed Budgets
      await db.insert(budgets).values([
        { categoryId: cats[0].id, limitAmount: "1500.00" }, // Housing
        { categoryId: cats[1].id, limitAmount: "600.00" },  // Food
        { categoryId: cats[2].id, limitAmount: "300.00" },  // Transport
      ]);

      // Seed Transactions
      await db.insert(transactions).values([
        { description: "Rent Payment", amount: "1500.00", categoryId: cats[0].id, date: new Date() },
        { description: "Grocery Run", amount: "124.50", categoryId: cats[1].id, date: new Date(Date.now() - 86400000) },
        { description: "Gas", amount: "45.00", categoryId: cats[2].id, date: new Date(Date.now() - 172800000) },
        { description: "Netflix", amount: "15.99", categoryId: cats[3].id, date: new Date(Date.now() - 259200000) },
      ]);
    }
  }
}

export const storage = new DatabaseStorage();
