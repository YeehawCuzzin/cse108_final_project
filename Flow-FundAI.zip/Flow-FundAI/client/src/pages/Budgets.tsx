import { Layout } from "@/components/Layout";
import { useBudgets, useCreateBudget, useUpdateBudget } from "@/hooks/use-budgets";
import { useCategories, useCreateCategory } from "@/hooks/use-categories";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Plus, Settings } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import clsx from "clsx";
import { useToast } from "@/hooks/use-toast";

export default function Budgets() {
  const { data: budgets, isLoading } = useBudgets();
  const { data: categories } = useCategories();
  const [createOpen, setCreateOpen] = useState(false);

  if (isLoading) {
    return (
      <Layout>
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-32 bg-slate-200 rounded"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-48 bg-slate-200 rounded-2xl"></div>
            ))}
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Budgets</h1>
          <p className="text-slate-500 mt-1">Manage your spending limits by category</p>
        </div>
        <CreateBudgetDialog open={createOpen} onOpenChange={setCreateOpen} categories={categories || []} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {budgets?.map((budget) => {
          const limit = Number(budget.limitAmount);
          const spent = Number(budget.spent);
          const percentage = Math.min((spent / limit) * 100, 100);
          const isOverBudget = spent > limit;

          return (
            <div 
              key={budget.id} 
              className="group bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-all duration-300 relative overflow-hidden"
            >
              {isOverBudget && (
                <div className="absolute top-0 right-0 w-16 h-16 bg-red-50 rounded-bl-full -mr-8 -mt-8" />
              )}
              
              <div className="flex justify-between items-start mb-4 relative z-10">
                <div>
                  <h3 className="font-bold text-lg text-slate-900">{budget.category.name}</h3>
                  <p className="text-sm text-slate-500">Monthly Limit</p>
                </div>
                <UpdateBudgetDialog budget={budget} />
              </div>

              <div className="mb-6 relative z-10">
                <div className="flex justify-between items-end mb-2">
                  <span className={clsx("text-2xl font-bold", isOverBudget ? "text-red-600" : "text-slate-900")}>
                    ${spent.toLocaleString()}
                  </span>
                  <span className="text-sm font-medium text-slate-400">
                    of ${limit.toLocaleString()}
                  </span>
                </div>
                <Progress 
                  value={percentage} 
                  className={clsx("h-3 bg-slate-100", 
                    isOverBudget ? "[&>div]:bg-red-500" : "[&>div]:bg-blue-500"
                  )} 
                />
              </div>

              <div className="flex justify-between items-center text-sm relative z-10">
                <span className={clsx(
                  "px-2 py-1 rounded-md font-medium",
                  isOverBudget ? "bg-red-100 text-red-700" : "bg-blue-50 text-blue-700"
                )}>
                  {percentage.toFixed(0)}% Used
                </span>
                <span className="text-slate-400">
                  ${(limit - spent).toLocaleString()} left
                </span>
              </div>
            </div>
          );
        })}

        {/* Add New Card Placeholder */}
        <div 
          onClick={() => setCreateOpen(true)}
          className="border-2 border-dashed border-slate-200 rounded-2xl p-6 flex flex-col items-center justify-center text-slate-400 hover:border-blue-400 hover:text-blue-500 hover:bg-blue-50/50 transition-all cursor-pointer min-h-[200px]"
        >
          <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mb-3 group-hover:bg-blue-100 transition-colors">
            <Plus className="w-6 h-6" />
          </div>
          <span className="font-medium">Create New Budget</span>
        </div>
      </div>
    </Layout>
  );
}

function CreateBudgetDialog({ open, onOpenChange, categories }: { open: boolean, onOpenChange: (o: boolean) => void, categories: any[] }) {
  const { mutate, isPending } = useCreateBudget();
  const { mutate: createCategory, isPending: creatingCat } = useCreateCategory();
  const { toast } = useToast();
  const [mode, setMode] = useState<'budget' | 'category'>('budget');
  
  const [amount, setAmount] = useState("");
  const [categoryId, setCategoryId] = useState("");
  
  const [newCatName, setNewCatName] = useState("");
  const [newCatColor, setNewCatColor] = useState("#3b82f6");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'budget') {
      mutate({ limitAmount: amount, categoryId: parseInt(categoryId) }, {
        onSuccess: () => {
          onOpenChange(false);
          setAmount("");
          setCategoryId("");
          toast({ title: "Budget created" });
        },
        onError: (err) => toast({ variant: "destructive", title: "Error", description: err.message })
      });
    } else {
      createCategory({ name: newCatName, color: newCatColor }, {
        onSuccess: () => {
          setMode('budget');
          setNewCatName("");
          toast({ title: "Category created", description: "Now you can assign a budget to it." });
        },
        onError: (err) => toast({ variant: "destructive", title: "Error", description: err.message })
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{mode === 'budget' ? 'Create Budget' : 'Create Category'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          {mode === 'budget' ? (
            <>
              <div className="space-y-2">
                <Label>Category</Label>
                <div className="flex gap-2">
                  <Select value={categoryId} onValueChange={setCategoryId}>
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(c => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <Button type="button" variant="outline" onClick={() => setMode('category')}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Monthly Limit ($)</Label>
                <Input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="1000" />
              </div>
            </>
          ) : (
            <>
              <div className="space-y-2">
                <Label>Category Name</Label>
                <Input value={newCatName} onChange={e => setNewCatName(e.target.value)} placeholder="e.g. Groceries" />
              </div>
              <div className="space-y-2">
                <Label>Color Helper</Label>
                <div className="flex gap-2">
                  {['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6'].map(c => (
                    <div 
                      key={c} 
                      onClick={() => setNewCatColor(c)}
                      className={clsx("w-6 h-6 rounded-full cursor-pointer border-2", newCatColor === c ? "border-slate-900" : "border-transparent")}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>
              <Button type="button" variant="ghost" onClick={() => setMode('budget')} className="text-sm">
                Back to Budget
              </Button>
            </>
          )}
          <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isPending || creatingCat}>
            {mode === 'budget' ? 'Save Budget' : 'Create Category'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function UpdateBudgetDialog({ budget }: { budget: any }) {
  const { mutate, isPending } = useUpdateBudget();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState(budget.limitAmount);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutate({ id: budget.id, limitAmount: amount }, {
      onSuccess: () => {
        setOpen(false);
        toast({ title: "Budget updated" });
      },
      onError: (err) => toast({ variant: "destructive", title: "Error", description: err.message })
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="text-slate-300 hover:text-slate-600 transition-colors">
          <Settings className="w-5 h-5" />
        </button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Update {budget.category.name} Budget</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label>Monthly Limit ($)</Label>
            <Input type="number" value={amount} onChange={e => setAmount(e.target.value)} />
          </div>
          <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isPending}>
            Update Limit
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
