import { ArrowUpRight, ArrowDownRight, type LucideIcon } from "lucide-react";
import clsx from "clsx";

interface StatsCardProps {
  title: string;
  value: string;
  trend?: string;
  trendUp?: boolean;
  icon: LucideIcon;
  colorClass: string;
}

export function StatsCard({ title, value, trend, trendUp, icon: Icon, colorClass }: StatsCardProps) {
  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-shadow duration-300">
      <div className="flex items-start justify-between mb-4">
        <div className={clsx("p-3 rounded-xl bg-opacity-10", colorClass.replace('text-', 'bg-'))}>
          <Icon className={clsx("w-6 h-6", colorClass)} />
        </div>
        {trend && (
          <div className={clsx(
            "flex items-center gap-1 text-sm font-semibold px-2 py-1 rounded-full",
            trendUp ? "text-emerald-600 bg-emerald-50" : "text-rose-600 bg-rose-50"
          )}>
            {trendUp ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
            {trend}
          </div>
        )}
      </div>
      <div>
        <p className="text-slate-500 text-sm font-medium">{title}</p>
        <h3 className="text-2xl font-bold text-slate-900 mt-1">{value}</h3>
      </div>
    </div>
  );
}
