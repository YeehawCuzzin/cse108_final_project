import { Link, useLocation } from "wouter";
import { LayoutDashboard, Wallet, CreditCard, PieChart } from "lucide-react";
import clsx from "clsx";

const navItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/budgets", label: "Budgets", icon: Wallet },
  { href: "/transactions", label: "Transactions", icon: CreditCard },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-slate-900 text-white min-h-screen hidden md:flex flex-col flex-shrink-0">
      <div className="p-6 border-b border-slate-800 flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-blue-500 flex items-center justify-center">
          <PieChart className="w-5 h-5 text-white" />
        </div>
        <h1 className="text-xl font-bold font-display tracking-tight">FlowFundAI</h1>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={clsx(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 cursor-pointer group",
                  isActive
                    ? "bg-blue-600 text-white shadow-lg shadow-blue-900/20"
                    : "text-slate-400 hover:text-white hover:bg-slate-800"
                )}
              >
                <Icon
                  className={clsx(
                    "w-5 h-5 transition-transform group-hover:scale-110",
                    isActive ? "text-white" : "text-slate-400 group-hover:text-white"
                  )}
                />
                <span className="font-medium">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-6 border-t border-slate-800">
        <div className="bg-slate-800 rounded-xl p-4">
          <p className="text-xs text-slate-400 font-medium mb-1">Monthly Plan</p>
          <div className="flex items-end justify-between">
            <span className="text-white font-bold">Pro</span>
            <span className="text-xs text-blue-400 cursor-pointer hover:underline">Upgrade</span>
          </div>
        </div>
      </div>
    </div>
  );
}
